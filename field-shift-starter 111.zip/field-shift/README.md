# Field Shift

A runnable full-stack starter for the Field Shift agricultural platform.

## Included
- Next.js + TypeScript + Tailwind frontend.
- FastAPI backend with live NASA POWER daily-data retrieval, a transparent starter crop-rotation simulator, and an AI gateway that activates only when configured.
- Supabase/PostgreSQL migration for farms, crop rotation, community groups/posts, markets, produce listings and notifications, with initial RLS policies.
- Pages for Dashboard, NASA Data, Rotation Lab, AI Assistant, Community and Market Connect.

This is a working foundation, not a deployed or production-ready service. Supabase credentials are needed for real accounts/database operations. An AI provider key and model are needed to activate the AI endpoint. Market/community screens are clearly marked as not yet connected to live records.

## Requirements
- Node.js 20+
- Python 3.11+
- Git
- Supabase project (for authentication/database)

## Run the API
```bash
cd apps/api
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```
API docs: http://localhost:8000/docs

Example NASA data request:
`GET http://localhost:8000/environment/power?latitude=-1.95&longitude=30.06`

## Run the web app
In a second terminal:
```bash
cd apps/web
npm install
copy .env.example .env.local
npm run dev
```
Use `cp .env.example .env.local` on macOS/Linux. Open http://localhost:3000.

Set `NEXT_PUBLIC_API_URL=http://localhost:8000` in `.env.local`.

## Configure Supabase
1. Create a Supabase project.
2. Run `supabase/migrations/001_initial_schema.sql` in the Supabase SQL Editor.
3. Enable Email and/or Google authentication in Supabase Auth.
4. Set these values in `apps/web/.env.local`:
```env
NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
NEXT_PUBLIC_API_URL=http://localhost:8000
```
The browser client helper is included. Complete sign-in screens and server-side session protection before launch. Never expose the Supabase service-role key in frontend code.

## Activate AI
Copy `apps/api/.env.example` to `apps/api/.env`, then set:
```env
AI_API_KEY=your_provider_key
AI_BASE_URL=https://api.openai.com/v1
AI_MODEL=your-supported-model
```
Restart the API. Without a key/model, `/ai/chat` returns HTTP 503 instead of pretending the assistant is live. The initial assistant is not yet grounded in verified agronomy sources, farm records, community content or market data.

## Team workflow
1. Project lead: integration, GitHub, documentation and demo.
2. NASA data: verify environmental variables, units, dates and limitations.
3. Agronomy: Rwanda crop catalogue, crop calendars and validated rotation rules.
4. Backend: API, simulator, database integration and tests.
5. Frontend: pages, responsive UI and accessibility.
6. AI/community/markets: grounded assistant, moderation and verified market records.

Create a GitHub repository, then:
```bash
git init
git add .
git commit -m "Initial Field Shift platform"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

## Important limitations
- Rotation scoring is an educational starter, not validated agronomic advice. Localize it with Rwanda-specific calendars, crop traits, soil information and expert review.
- NASA POWER is gridded environmental data, not an exact farm sensor or forecast.
- SMAP, GPM IMERG, SoilGrids and weather forecasts are not yet integrated.
- Community and Market Connect are interface/schema foundations; real records and full authenticated workflows still need implementation.
- Buyer accounts are intentionally postponed.
- Market prices must include a source, observation date, currency and unit. Do not invent prices or expose farmer contact details without consent.
- Add tests, rate limits, logging, backups, security review and deployment configuration before production use.
