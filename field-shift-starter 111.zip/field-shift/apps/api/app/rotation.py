LEGUMES = {"beans", "soybean", "groundnut", "peas"}
CEREALS = {"maize", "rice", "sorghum", "wheat"}

def simulate(current_crop: str, next_crop: str, soil_type: str, priority: str):
    current, nxt = current_crop.strip().lower(), next_crop.strip().lower()
    score, reasons, cautions = 50, [], []
    if current in CEREALS and nxt in LEGUMES:
        score += 25
        reasons.append("A cereal-to-legume sequence diversifies nutrient demand; many legumes can fix atmospheric nitrogen.")
    elif current in LEGUMES and nxt in CEREALS:
        score += 18
        reasons.append("A legume-to-cereal sequence may use residual nitrogen, depending on residue management and soil conditions.")
    elif current == nxt:
        score -= 20
        cautions.append("Repeating the same crop can increase pest, disease and nutrient-management pressure.")
    else:
        reasons.append("The crops differ; benefits depend on crop family, disease history, rooting depth and local management.")
    if soil_type == "sandy":
        cautions.append("Sandy soils often retain less water and nutrients; consider organic matter and water management.")
    elif soil_type == "clay":
        cautions.append("Clay soils may drain slowly; check field drainage and crop tolerance.")
    elif soil_type == "unknown":
        cautions.append("Soil type is unknown, so soil-specific suitability cannot be assessed.")
    if priority == "water_efficiency":
        cautions.append("Compare crop water needs with seasonal rainfall and irrigation access.")
    elif priority == "income":
        cautions.append("Income depends on local demand, prices, input costs and market access; this score does not predict profit.")
    elif priority == "soil_health":
        reasons.append("The starter scoring emphasizes crop diversity and possible soil-health benefits, not guaranteed yield.")
    score = max(0, min(100, score))
    return {
        "score": score,
        "label": "Promising option to investigate" if score >= 70 else "Needs local review" if score >= 50 else "Higher-risk sequence",
        "current_crop": current_crop, "next_crop": next_crop,
        "reasons": reasons, "cautions": cautions,
        "method": "Illustrative rule-based screening; not a validated agronomic recommendation."
    }
