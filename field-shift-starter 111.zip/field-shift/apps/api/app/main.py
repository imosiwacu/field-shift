from datetime import date, timedelta
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import httpx
from .config import settings
from .schemas import RotationRequest, ChatRequest
from .rotation import simulate

app = FastAPI(title="Field Shift API", version="0.1.0",
              description="Agricultural decision-support API starter.")
origins = [x.strip() for x in settings.cors_origins.split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])

@app.get("/health")
def health():
    return {"status": "ok", "service": "field-shift-api"}

@app.get("/environment/power")
async def nasa_power(latitude: float, longitude: float,
                     start: str | None = None, end: str | None = None):
    end_date = date.today() - timedelta(days=2)
    start_date = end_date - timedelta(days=13)
    start = start or start_date.strftime("%Y%m%d")
    end = end or end_date.strftime("%Y%m%d")
    if any(len(x) != 8 or not x.isdigit() for x in (start, end)):
        raise HTTPException(400, "Dates must use YYYYMMDD.")
    url = "https://power.larc.nasa.gov/api/temporal/daily/point"
    params = {
        "parameters": "T2M,PRECTOTCORR,ALLSKY_SFC_SW_DWN",
        "community": "AG", "longitude": longitude, "latitude": latitude,
        "start": start, "end": end, "format": "JSON"
    }
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.get(url, params=params)
            response.raise_for_status()
            payload = response.json()
    except (httpx.HTTPError, ValueError) as exc:
        raise HTTPException(502, f"NASA POWER request failed: {exc}")
    properties = payload.get("properties", {})
    return {
        "source": "NASA POWER", "community": "AG",
        "coordinates": {"latitude": latitude, "longitude": longitude},
        "requested_period": {"start": start, "end": end},
        "units": {"T2M": "°C", "PRECTOTCORR": "mm/day", "ALLSKY_SFC_SW_DWN": "kWh/m²/day"},
        "parameters": properties.get("parameter", {}),
        "metadata": properties.get("header", {}),
        "limitations": [
            "Gridded NASA POWER estimates are not measurements from the exact farm.",
            "Historical daily data are not a weather forecast.",
            "Check missing-value codes and product documentation before analysis."
        ]
    }

@app.post("/rotation/simulate")
def rotation_simulate(request: RotationRequest):
    return simulate(request.current_crop, request.next_crop, request.soil_type, request.priority)

@app.post("/ai/chat")
async def ai_chat(request: ChatRequest):
    if not settings.ai_api_key or not settings.ai_model:
        raise HTTPException(503, "AI is not configured. Add AI_API_KEY and AI_MODEL to apps/api/.env.")
    body = {
        "model": settings.ai_model,
        "messages": [
            {"role": "system", "content": "You are Field Shift's agricultural information assistant. Do not invent measurements, prices, buyers, forecasts or sources. Distinguish historical observations from forecasts. State uncertainty and advise local expert verification for important agronomic decisions. Supplied context may be incomplete."},
            {"role": "user", "content": f"Context: {request.context}\n\nQuestion: {request.message}"}
        ],
        "temperature": 0.3
    }
    try:
        async with httpx.AsyncClient(timeout=60) as client:
            response = await client.post(settings.ai_base_url.rstrip("/") + "/chat/completions",
                headers={"Authorization": f"Bearer {settings.ai_api_key}"}, json=body)
            response.raise_for_status()
            data = response.json()
        return {"answer": data["choices"][0]["message"]["content"],
                "grounding": "User-provided context only; no verified farm or market database is connected yet."}
    except (httpx.HTTPError, KeyError, IndexError, ValueError) as exc:
        raise HTTPException(502, f"AI provider request failed: {exc}")
