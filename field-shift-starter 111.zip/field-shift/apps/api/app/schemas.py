from pydantic import BaseModel, Field
from typing import Literal

class RotationRequest(BaseModel):
    current_crop: str
    next_crop: str
    soil_type: Literal["clay", "loam", "sandy", "unknown"] = "unknown"
    priority: Literal["soil_health", "water_efficiency", "income", "balanced"] = "balanced"

class ChatRequest(BaseModel):
    message: str = Field(min_length=2, max_length=4000)
    context: dict = Field(default_factory=dict)
