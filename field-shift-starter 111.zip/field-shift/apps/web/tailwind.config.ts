import type { Config } from "tailwindcss";
const config: Config = {
 content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
 theme: { extend: { colors: { field: { 950: "#10251d", 900: "#18382b", 700: "#2f684b", 100: "#e9f3eb", 50: "#f5f9f5" } } } },
 plugins: [],
};
export default config;
