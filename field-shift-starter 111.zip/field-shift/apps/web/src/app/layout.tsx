import "./globals.css";
import type { Metadata } from "next";
import Link from "next/link";
export const metadata: Metadata = { title: "Field Shift | Smarter farming with Earth data", description: "Environmental intelligence, crop rotation and farmer collaboration." };
const nav = [["Dashboard","/"],["NASA Data","/environment"],["Rotation Lab","/rotation"],["AI Assistant","/assistant"],["Community","/community"],["Market Connect","/markets"]];
export default function RootLayout({children}:{children:React.ReactNode}) {
 return <html lang="en"><body>
  <header className="border-b border-emerald-950/10 bg-white"><div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-5 py-4">
   <Link href="/" className="text-xl font-black tracking-tight text-field-900">FIELD<span className="text-emerald-600">SHIFT</span></Link>
   <nav className="flex flex-wrap gap-x-5 gap-y-2 text-sm font-semibold text-slate-600">{nav.map(([label,href])=><Link key={href} href={href} className="hover:text-emerald-700">{label}</Link>)}</nav>
  </div></header>
  <main className="mx-auto min-h-[80vh] max-w-7xl px-5 py-8">{children}</main>
  <footer className="border-t bg-white px-5 py-6 text-center text-xs text-slate-500">Field Shift · NASA Earth observations for better-informed farming · Data limitations apply</footer>
 </body></html>;
}
