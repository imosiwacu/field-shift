"use client";
import {useState} from "react";
const API=process.env.NEXT_PUBLIC_API_URL||"http://localhost:8000";
export default function AssistantPage(){
 const [message,setMessage]=useState("How can I think about rotating beans after maize?"),[answer,setAnswer]=useState(""),[error,setError]=useState(""),[busy,setBusy]=useState(false);
 async function ask(){setBusy(true);setError("");setAnswer("");try{const r=await fetch(`${API}/ai/chat`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message,context:{product:"Field Shift",region:"Rwanda",note:"No farm profile or verified market data connected yet."}})});const d=await r.json();if(!r.ok)throw new Error(d.detail||"AI request failed");setAnswer(d.answer+"\n\n"+d.grounding);}catch(e){setError(e instanceof Error?e.message:"Could not reach AI service.");}finally{setBusy(false);}}
 return <div className="max-w-3xl space-y-6"><div><p className="text-xs font-bold uppercase tracking-widest text-emerald-700">Field Shift AI</p><h1 className="mt-2 text-3xl font-black">Agricultural assistant</h1><p className="mt-2 text-slate-600">The AI gateway activates when a provider key and model are configured.</p></div>
 <div className="rounded-2xl border bg-white p-5"><label className="text-sm font-bold">Your question<textarea value={message} onChange={e=>setMessage(e.target.value)} rows={4} className="mt-2 w-full rounded-xl border p-3 font-normal"/></label><button disabled={busy||message.trim().length<2} onClick={ask} className="mt-3 rounded-lg bg-field-900 px-5 py-3 font-bold text-white disabled:opacity-50">{busy?"Thinking…":"Ask Field Shift AI"}</button></div>
 {error&&<div className="rounded-xl bg-amber-50 p-4 text-sm text-amber-900">{error}</div>}{answer&&<div className="whitespace-pre-wrap rounded-2xl border bg-white p-5 text-sm leading-7">{answer}</div>}
 <p className="text-xs leading-5 text-slate-500">This endpoint is not yet grounded in live NASA observations, verified agricultural references, community posts or market records.</p></div>;
}
