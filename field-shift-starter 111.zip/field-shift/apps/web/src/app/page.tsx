import Link from "next/link";
import { ArrowRight, CloudSun, Sprout, Bot, Users, MapPinned } from "lucide-react";
const features = [
 {icon:CloudSun,title:"NASA Environmental Intelligence",desc:"Explore historical temperature, precipitation and solar-radiation data for a selected location.",href:"/environment"},
 {icon:Sprout,title:"Crop Rotation Lab",desc:"Compare crop sequences with transparent starter rules, reasons and cautions.",href:"/rotation"},
 {icon:Bot,title:"Field Shift AI",desc:"Ask questions with clear limits. Connect an AI provider key to activate the gateway.",href:"/assistant"},
 {icon:Users,title:"Farmer Community",desc:"Discover public groups for crops, locations and shared farming challenges.",href:"/community"},
 {icon:MapPinned,title:"Market Connect",desc:"A foundation for physical market discovery and farmer-to-buyer connections.",href:"/markets"}
];
export default function Home(){return <div className="space-y-12">
 <section className="overflow-hidden rounded-3xl bg-field-950 px-7 py-14 text-white md:px-12"><div className="max-w-3xl">
  <p className="mb-4 text-xs font-bold uppercase tracking-[.25em] text-emerald-300">Agriculture · Earth observation · Community</p>
  <h1 className="text-4xl font-black leading-tight md:text-6xl">Make every field decision more informed.</h1>
  <p className="mt-5 max-w-2xl text-base leading-7 text-emerald-50/80">Field Shift brings environmental intelligence, crop-rotation exploration, an agricultural AI assistant, farmer groups and market discovery into one platform.</p>
  <div className="mt-8 flex flex-wrap gap-3"><Link href="/rotation" className="rounded-xl bg-emerald-400 px-5 py-3 font-bold text-field-950">Explore Rotation Lab <ArrowRight className="ml-2 inline" size={17}/></Link><Link href="/environment" className="rounded-xl border border-white/30 px-5 py-3 font-bold hover:bg-white/10">Explore NASA data</Link></div>
 </div></section>
 <section><div className="mb-6"><p className="text-xs font-bold uppercase tracking-widest text-emerald-700">The platform</p><h2 className="mt-2 text-3xl font-extrabold">Five connected tools</h2></div>
  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">{features.map(({icon:Icon,title,desc,href})=><Link href={href} key={href} className="rounded-2xl border border-slate-200 bg-white p-6 transition hover:-translate-y-1 hover:shadow-lg"><div className="mb-5 inline-flex rounded-xl bg-field-100 p-3 text-field-700"><Icon size={23}/></div><h3 className="text-lg font-bold">{title}</h3><p className="mt-2 text-sm leading-6 text-slate-600">{desc}</p><span className="mt-5 inline-flex items-center text-sm font-bold text-emerald-700">Open tool <ArrowRight size={15} className="ml-2"/></span></Link>)}</div>
 </section>
 <section className="rounded-2xl border border-amber-200 bg-amber-50 p-5 text-sm leading-6 text-amber-950"><strong>Development status:</strong> NASA POWER is connected through the API. Rotation scoring is illustrative and requires agronomic validation. AI needs a provider key. Community and market screens are foundations, not live directories.</section>
</div>}
