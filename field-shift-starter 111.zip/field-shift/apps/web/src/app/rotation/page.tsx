"use client";
import {useState} from "react";
const API=process.env.NEXT_PUBLIC_API_URL||"http://localhost:8000";
type Result={score:number;label:string;reasons:string[];cautions:string[];method:string};
export default function RotationPage(){
 const [current,setCurrent]=useState("maize"),[next,setNext]=useState("beans"),[soil,setSoil]=useState("unknown"),[priority,setPriority]=useState("balanced"),[result,setResult]=useState<Result|null>(null),[error,setError]=useState("");
 async function run(){setError("");setResult(null);try{const r=await fetch(`${API}/rotation/simulate`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({current_crop:current,next_crop:next,soil_type:soil,priority})});if(!r.ok)throw new Error("API request failed. Start FastAPI.");setResult(await r.json());}catch(e){setError(e instanceof Error?e.message:"Could not simulate.");}}
 return <div className="max-w-4xl space-y-6"><div><p className="text-xs font-bold uppercase tracking-widest text-emerald-700">Core challenge tool</p><h1 className="mt-2 text-3xl font-black">Crop Rotation Lab</h1><p className="mt-2 text-slate-600">Explore a crop sequence and see why it may be worth investigating.</p></div>
 <div className="grid gap-4 rounded-2xl border bg-white p-5 md:grid-cols-2">
 <label className="text-sm font-semibold">Previous/current crop<select value={current} onChange={e=>setCurrent(e.target.value)} className="mt-2 w-full rounded-lg border p-3 font-normal">{["maize","beans","rice","soybean","groundnut","sorghum","peas"].map(x=><option key={x}>{x}</option>)}</select></label>
 <label className="text-sm font-semibold">Proposed next crop<select value={next} onChange={e=>setNext(e.target.value)} className="mt-2 w-full rounded-lg border p-3 font-normal">{["beans","maize","rice","soybean","groundnut","sorghum","peas"].map(x=><option key={x}>{x}</option>)}</select></label>
 <label className="text-sm font-semibold">Soil type<select value={soil} onChange={e=>setSoil(e.target.value)} className="mt-2 w-full rounded-lg border p-3 font-normal">{["unknown","clay","loam","sandy"].map(x=><option key={x}>{x}</option>)}</select></label>
 <label className="text-sm font-semibold">Main priority<select value={priority} onChange={e=>setPriority(e.target.value)} className="mt-2 w-full rounded-lg border p-3 font-normal">{[["balanced","Balanced"],["soil_health","Soil health"],["water_efficiency","Water efficiency"],["income","Income"]].map(([v,l])=><option key={v} value={v}>{l}</option>)}</select></label>
 <button onClick={run} className="rounded-lg bg-field-900 p-3 font-bold text-white md:col-span-2">Simulate rotation</button></div>
 {error&&<p className="rounded-xl bg-red-50 p-4 text-sm text-red-700">{error}</p>}
 {result&&<section className="space-y-4 rounded-2xl border bg-white p-5"><div className="flex flex-wrap items-center justify-between gap-3"><div><p className="text-xs font-bold uppercase tracking-widest text-emerald-700">Starter screening result</p><h2 className="mt-1 text-2xl font-black">{result.label}</h2></div><div className="rounded-xl bg-field-100 px-4 py-3 text-center"><p className="text-3xl font-black text-field-900">{result.score}<span className="text-sm">/100</span></p><p className="text-xs text-slate-500">illustrative score</p></div></div>
 <div><h3 className="font-bold">Why this sequence?</h3><ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-slate-600">{result.reasons.map(x=><li key={x}>{x}</li>)}</ul></div>
 <div><h3 className="font-bold">Cautions</h3><ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-slate-600">{result.cautions.map(x=><li key={x}>{x}</li>)}</ul></div>
 <p className="rounded-lg bg-amber-50 p-3 text-xs leading-5 text-amber-900">{result.method} Validate with local agronomic expertise before planting.</p></section>}</div>;
}
