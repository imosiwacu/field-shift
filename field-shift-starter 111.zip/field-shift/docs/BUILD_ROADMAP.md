# Build roadmap

## First: core NASA challenge workflow
1. Connect a farm coordinate to NASA POWER.
2. Add farm profiles and persist them in Supabase.
3. Add Rwanda-specific crop catalogue and crop calendar.
4. Replace starter rotation scoring with tested, expert-reviewed rules.
5. Show source dates, units, missing values and limitations.
6. Demo farm location → NASA data → rotation comparison.

## Then: AI and community
1. Configure AI provider and test the gateway.
2. Retrieve only authorized farm context for each AI request.
3. Ground answers in curated, reviewed agricultural sources.
4. Complete Supabase auth and secure session handling.
5. Implement group join, posts, comments, reactions and reporting.
6. Add moderation roles and audit events.

## Then: Market Connect
1. Collect and verify physical market records and coordinates.
2. Add Leaflet/OpenStreetMap map with attribution.
3. Add farmer produce listings with explicit privacy consent.
4. Add verified buyer contacts; buyer accounts remain postponed.
5. Add prices only with source, date, currency and unit.

Definition of done: each feature works end-to-end, has loading/empty/error states, uses real data or is labelled demo, validates permissions server-side, and has a test.
