# Six-person team task split

| Member | Ownership | First deliverable |
|---|---|---|
| 1 | Project lead / integration | GitHub repo, issue board, demo script |
| 2 | NASA data | Verify POWER variables, units, dates and error handling |
| 3 | Agronomy | Rwanda crop calendar, crop families and reviewed rotation rules |
| 4 | Backend | API tests, farm endpoints and simulator refinement |
| 5 | Frontend | Responsive dashboard and end-to-end flow |
| 6 | AI / community / market | AI grounding plan, group schema review, verified market data plan |

Commit small changes frequently and integrate daily. Prioritize the NASA-to-rotation path over disconnected secondary screens.
