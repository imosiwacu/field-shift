create extension if not exists pgcrypto;

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 display_name text, preferred_language text not null default 'en',
 created_at timestamptz not null default now()
);
create table if not exists public.farms (
 id uuid primary key default gen_random_uuid(),
 owner_id uuid not null references auth.users(id) on delete cascade,
 name text not null, latitude double precision, longitude double precision,
 district text, soil_type text check (soil_type in ('clay','loam','sandy','unknown')),
 created_at timestamptz not null default now(),
 check (latitude is null or latitude between -90 and 90),
 check (longitude is null or longitude between -180 and 180)
);
create table if not exists public.crop_catalog (
 id uuid primary key default gen_random_uuid(), name text not null unique,
 crop_family text, is_legume boolean not null default false, notes text
);
create table if not exists public.crop_rotation_plans (
 id uuid primary key default gen_random_uuid(),
 farm_id uuid not null references public.farms(id) on delete cascade,
 created_by uuid not null references auth.users(id) on delete cascade,
 plan_name text not null, created_at timestamptz not null default now()
);
create table if not exists public.rotation_results (
 id uuid primary key default gen_random_uuid(),
 plan_id uuid not null references public.crop_rotation_plans(id) on delete cascade,
 sequence jsonb not null, score numeric,
 explanation jsonb not null default '{}'::jsonb, created_at timestamptz not null default now()
);
create table if not exists public.community_groups (
 id uuid primary key default gen_random_uuid(), name text not null,
 description text, category text not null, is_public boolean not null default true,
 created_by uuid references auth.users(id) on delete set null, created_at timestamptz not null default now()
);
create table if not exists public.group_members (
 group_id uuid not null references public.community_groups(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 role text not null default 'member' check (role in ('member','moderator')),
 joined_at timestamptz not null default now(), primary key (group_id,user_id)
);
create table if not exists public.community_posts (
 id uuid primary key default gen_random_uuid(),
 group_id uuid not null references public.community_groups(id) on delete cascade,
 author_id uuid not null references auth.users(id) on delete cascade,
 body text not null, image_path text, created_at timestamptz not null default now()
);
create table if not exists public.community_comments (
 id uuid primary key default gen_random_uuid(),
 post_id uuid not null references public.community_posts(id) on delete cascade,
 author_id uuid not null references auth.users(id) on delete cascade,
 body text not null, created_at timestamptz not null default now()
);
create table if not exists public.post_reactions (
 post_id uuid not null references public.community_posts(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 reaction text not null, created_at timestamptz not null default now(),
 primary key (post_id,user_id,reaction)
);
create table if not exists public.community_reports (
 id uuid primary key default gen_random_uuid(),
 reporter_id uuid not null references auth.users(id) on delete cascade,
 post_id uuid references public.community_posts(id) on delete cascade,
 reason text not null, status text not null default 'open'
 check (status in ('open','reviewing','resolved','dismissed')),
 created_at timestamptz not null default now()
);
create table if not exists public.markets (
 id uuid primary key default gen_random_uuid(), name text not null, address text,
 district text, latitude double precision, longitude double precision,
 verified boolean not null default false, source_name text, source_checked_at timestamptz,
 created_at timestamptz not null default now()
);
create table if not exists public.market_prices (
 id uuid primary key default gen_random_uuid(),
 market_id uuid not null references public.markets(id) on delete cascade,
 crop_name text not null, price numeric not null check (price >= 0),
 currency text not null, unit text not null, observed_at date not null, source_name text not null
);
create table if not exists public.saved_markets (
 market_id uuid not null references public.markets(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 created_at timestamptz not null default now(), primary key (market_id,user_id)
);
create table if not exists public.produce_listings (
 id uuid primary key default gen_random_uuid(),
 farmer_id uuid not null references auth.users(id) on delete cascade,
 crop_name text not null, quantity numeric not null check (quantity > 0),
 unit text not null, expected_price numeric, currency text, district text,
 description text, contact_opt_in boolean not null default false,
 status text not null default 'draft' check (status in ('draft','published','closed')),
 created_at timestamptz not null default now()
);
create table if not exists public.notifications (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 title text not null, body text not null, read_at timestamptz,
 created_at timestamptz not null default now()
);

create index if not exists farms_owner_idx on public.farms(owner_id);
create index if not exists group_members_user_idx on public.group_members(user_id);
create index if not exists posts_group_created_idx on public.community_posts(group_id,created_at desc);
create index if not exists markets_district_idx on public.markets(district);
create index if not exists listings_crop_status_idx on public.produce_listings(crop_name,status);

alter table public.profiles enable row level security;
alter table public.farms enable row level security;
alter table public.crop_rotation_plans enable row level security;
alter table public.rotation_results enable row level security;
alter table public.group_members enable row level security;
alter table public.community_posts enable row level security;
alter table public.community_comments enable row level security;
alter table public.post_reactions enable row level security;
alter table public.community_reports enable row level security;
alter table public.saved_markets enable row level security;
alter table public.produce_listings enable row level security;
alter table public.notifications enable row level security;
alter table public.community_groups enable row level security;
alter table public.crop_catalog enable row level security;
alter table public.markets enable row level security;
alter table public.market_prices enable row level security;

create policy "profiles readable by authenticated" on public.profiles for select to authenticated using (true);
create policy "users update own profile" on public.profiles for update to authenticated using (auth.uid()=id) with check (auth.uid()=id);
create policy "users insert own profile" on public.profiles for insert to authenticated with check (auth.uid()=id);
create policy "owners manage farms" on public.farms for all to authenticated using (auth.uid()=owner_id) with check (auth.uid()=owner_id);
create policy "owners manage rotation plans" on public.crop_rotation_plans for all to authenticated using (auth.uid()=created_by) with check (auth.uid()=created_by);
create policy "rotation results through owned plans" on public.rotation_results for all to authenticated
 using (exists(select 1 from public.crop_rotation_plans p where p.id=plan_id and p.created_by=auth.uid()))
 with check (exists(select 1 from public.crop_rotation_plans p where p.id=plan_id and p.created_by=auth.uid()));
create policy "public groups readable" on public.community_groups for select using (is_public=true);
create policy "authenticated create groups" on public.community_groups for insert to authenticated with check (created_by=auth.uid());
create policy "members readable" on public.group_members for select to authenticated using (true);
create policy "users join as themselves" on public.group_members for insert to authenticated with check (user_id=auth.uid() and role='member');
create policy "users leave themselves" on public.group_members for delete to authenticated using (user_id=auth.uid());
create policy "public posts readable" on public.community_posts for select using (exists(select 1 from public.community_groups g where g.id=group_id and g.is_public=true));
create policy "members create posts" on public.community_posts for insert to authenticated with check (author_id=auth.uid() and exists(select 1 from public.group_members m where m.group_id=group_id and m.user_id=auth.uid()));
create policy "authors update own posts" on public.community_posts for update to authenticated using (author_id=auth.uid()) with check (author_id=auth.uid());
create policy "authors delete own posts" on public.community_posts for delete to authenticated using (author_id=auth.uid());
create policy "public comments readable" on public.community_comments for select using (exists(select 1 from public.community_posts p join public.community_groups g on g.id=p.group_id where p.id=post_id and g.is_public=true));
create policy "members comment" on public.community_comments for insert to authenticated with check (author_id=auth.uid() and exists(select 1 from public.community_posts p join public.group_members m on m.group_id=p.group_id where p.id=post_id and m.user_id=auth.uid()));
create policy "users manage own reactions" on public.post_reactions for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy "users create reports" on public.community_reports for insert to authenticated with check (reporter_id=auth.uid());
create policy "reporters read own reports" on public.community_reports for select to authenticated using (reporter_id=auth.uid());
create policy "public crop catalog" on public.crop_catalog for select using (true);
create policy "verified markets readable" on public.markets for select using (verified=true);
create policy "verified market prices readable" on public.market_prices for select using (exists(select 1 from public.markets m where m.id=market_id and m.verified=true));
create policy "users manage saved markets" on public.saved_markets for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy "published listings readable" on public.produce_listings for select using (status='published');
create policy "farmers manage own listings" on public.produce_listings for all to authenticated using (farmer_id=auth.uid()) with check (farmer_id=auth.uid());
create policy "users read own notifications" on public.notifications for select to authenticated using (user_id=auth.uid());
create policy "users update own notifications" on public.notifications for update to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
